﻿using Microsoft.AspNetCore.Mvc;
using ToDoListApp.Models;
using System.Globalization;
using System.IO;
using System.Text;

namespace ToDoListApp.Controllers
{
    public class TaskController : Controller
    {
        // Static list to store tasks (in-memory storage for now)
        private static List<TaskModel> tasks = new List<TaskModel>();
        private static int nextId = 1;

        // Display the task list
        public IActionResult Index()
        {
            return View(tasks);
        }

        // Show form to create a new task
        public IActionResult Create()
        {
            return View();
        }

        // Save new task to the list
        [HttpPost]
        public IActionResult Create(TaskModel task)
        {
            if (ModelState.IsValid)
            {
                task.Id = nextId++;
                task.DateStarted = DateTime.Now;
                tasks.Add(task);
                TempData["Message"] = "Task created successfully!";
                return RedirectToAction("Index");
            }
            return View(task);
        }

        // Mark task as completed
        public IActionResult Complete(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.Status = "Completed";
                task.DateCompleted = DateTime.Now;
            }
            return RedirectToAction("Index");
        }

        // Delete task
        public IActionResult Delete(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                tasks.Remove(task);
            }
            return RedirectToAction("Index");
        }

        // Export to CSV
        public IActionResult Export()
        {
            var csv = new StringBuilder();
            csv.AppendLine("Id,Title,Details,Assigned To,Status,Date Started,Date Completed");

            foreach (var task in tasks)
            {
                csv.AppendLine($"{task.Id},{task.Title},{task.Details},{task.AssignedTo},{task.Status},{task.DateStarted.ToString("g", CultureInfo.InvariantCulture)},{task.DateCompleted?.ToString("g", CultureInfo.InvariantCulture)}");
            }

            var fileName = "tasks.csv";
            var fileBytes = Encoding.UTF8.GetBytes(csv.ToString());
            return File(fileBytes, "text/csv", fileName);
        }

        // Import tasks from CSV
        [HttpPost]
        public IActionResult Import(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    var header = reader.ReadLine(); // Skip header row
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        // Add the task from CSV
                        var task = new TaskModel
                        {
                            Id = nextId++,
                            Title = values[0],
                            Details = values[1],
                            AssignedTo = values[2],
                            Status = values[3],
                            DateStarted = DateTime.Parse(values[4]),
                            DateCompleted = string.IsNullOrEmpty(values[5]) ? (DateTime?)null : DateTime.Parse(values[5])
                        };

                        tasks.Add(task);
                    }
                }
                TempData["Message"] = "Tasks imported successfully!";
            }
            else
            {
                TempData["Error"] = "No file selected or file is empty!";
            }

            return RedirectToAction("Index");
        }
    }
}
